//#include <reg52.h>
#include "DELAY1.h"

void Delay(Uint times)
  {
   while(times)
   {
    times--;
   }
  }
//----------------------------------------------------------
void M_Delay(Uint dela)
  {
	unsigned char i;
	for(;dela>0;dela--)
		for(i=0;i<125;i++);
  }