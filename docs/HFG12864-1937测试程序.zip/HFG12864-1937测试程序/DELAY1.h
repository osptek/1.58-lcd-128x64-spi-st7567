#ifndef __DELAY1_H__
#define __DELAY1_H__
#define Uchar unsigned char
#define Uint  unsigned int

extern void Delay(Uint times);
extern void M_Delay(Uint dela);

#endif