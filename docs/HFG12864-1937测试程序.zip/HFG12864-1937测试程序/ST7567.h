#ifndef __ST7567_H__
#define __ST7567_H__
#include<intrins.h>

#define Uchar unsigned char
#define Uint  unsigned int

#define somenop();_nop_();

/*
sbit CS1 =P3^4;		//CS0
sbit RST =P3^3;
sbit A0 = P3^2;		//CD
sbit SCK =P1^0;		//SCK		 //���ڽӿڶ���
sbit SI = P1^1;	  	//SDA
*/  

sbit CS1 =P3^4;	
sbit RST =P3^3;	
sbit A0  =P3^2;	  //���ڽӿڶ���
sbit RW  =P3^1;	
sbit E   =P3^0;
#define DATABUS  P1



extern void WriteData(Uchar data1, bit di);
extern void Init_LCD(void);
extern void Displine(Uchar array[]);
extern void display8(Uchar a[]);
extern void clearlcd(void);
extern void Dispgraphic(Uchar *p);
extern void Key_Scan(void);

#endif